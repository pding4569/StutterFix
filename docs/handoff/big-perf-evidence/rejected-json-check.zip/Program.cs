﻿using System;
using System.Collections;
using System.Globalization;
using System.IO;
using System.Linq;
using StutterFix;
class Program
{
    static int checks;
    static void Same(object a, object b)
    {
        checks++;
        if (a == null || b == null) { if (a != b) throw new Exception("null mismatch"); return; }
        if (a.GetType() != b.GetType()) throw new Exception("type mismatch");
        if (a is IDictionary d)
        {
            var e = ((IDictionary)b).GetEnumerator();
            foreach (DictionaryEntry p in d) { if (!e.MoveNext() || !Equals(p.Key, e.Key)) throw new Exception("key/order mismatch"); Same(p.Value, e.Value); }
            if (e.MoveNext()) throw new Exception("count mismatch");
        }
        else if (a is IList l)
        {
            var r = (IList)b; if (l.Count != r.Count) throw new Exception("count mismatch");
            for (int i = 0; i < l.Count; i++) Same(l[i], r[i]);
        }
        else if (a is float f) { if (BitConverter.SingleToInt32Bits(f) != BitConverter.SingleToInt32Bits((float)b)) throw new Exception("float bits mismatch"); }
        else if (!a.Equals(b)) throw new Exception("value mismatch");
    }
    static (object value, Type error) Parse(string s, bool compact)
    {
        FastJsonParser.CompactAllocations = compact;
        try { return (FastJsonParser.Parse(s), null); } catch (Exception e) { return (null, e.GetType()); }
    }
    static void Check(string s)
    {
        var a = Parse(s, false); var b = Parse(s, true);
        if (a.error != b.error) throw new Exception("exception mismatch");
        Same(a.value, b.value);
    }
    static void Main(string[] args)
    {
        FastJsonParser.ArrayLimit = 1000000;
        foreach (var culture in new[] { "en-US", "ko-KR", "de-DE", "fr-FR" })
        {
            CultureInfo.CurrentCulture = CultureInfo.GetCultureInfo(culture);
            foreach (var s in new[] { "0", "-0", "2147483648", "1e3", "1.0e3", "-0.0", "1.2e999", "1.", "[1,2.5,-2,1e2]", "[1:2]", "[", "{", "{\"a\":1,\"a\":2}", "{\"\\u0061\":-0.0}", "{\"x\":", "{\"a\":1,}", "\"x\\u12\"" }) Check(s);
        }
        CultureInfo.CurrentCulture = CultureInfo.GetCultureInfo("ko-KR");
        foreach (var path in args) { var n = checks; Check(File.ReadAllText(path)); Console.WriteLine($"{path}: {checks-n} typed/order/bit checks OK"); }
        Console.WriteLine($"Total {checks} checks; mismatches 0");
    }
}
